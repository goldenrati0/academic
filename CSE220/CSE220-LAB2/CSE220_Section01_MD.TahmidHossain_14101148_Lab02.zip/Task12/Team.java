public class Team{
    
  protected String name = null;
  
  Team(String name){
      
    this.name = name;
  }
}