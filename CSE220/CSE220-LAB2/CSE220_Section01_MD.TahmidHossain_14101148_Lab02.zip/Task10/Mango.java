public class Mango extends Fruit{
 
    public Mango(){
        
        super(true, "Mango");
    }
    
    public String toString(){
        
        return "Mangoes are bad for you";
    }
}